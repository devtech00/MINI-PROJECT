<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/st.png"  alt="" />
	      
           
</div>