<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/aq.png"  alt="" />
	      
           
</div>