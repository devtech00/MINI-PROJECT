<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/media.png"  alt="" />
	      
           
</div>